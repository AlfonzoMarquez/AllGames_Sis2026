---
name: Precision Quadratic
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c0c7d3'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#8a919d'
  outline-variant: '#404751'
  surface-tint: '#9fcaff'
  primary: '#9fcaff'
  on-primary: '#003258'
  primary-container: '#007acc'
  on-primary-container: '#ffffff'
  inverse-primary: '#0061a4'
  secondary: '#c6c4d9'
  on-secondary: '#2f2f3f'
  secondary-container: '#4a4a5b'
  on-secondary-container: '#bbbace'
  tertiary: '#ffb784'
  on-tertiary: '#4f2500'
  tertiary-container: '#b95e01'
  on-tertiary-container: '#ffffff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#9fcaff'
  on-primary-fixed: '#001d36'
  on-primary-fixed-variant: '#00497d'
  secondary-fixed: '#e3e0f6'
  secondary-fixed-dim: '#c6c4d9'
  on-secondary-fixed: '#1a1a29'
  on-secondary-fixed-variant: '#454556'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb784'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#713700'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-result:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-padding: 2rem
  element-gap: 1rem
  section-margin: 2.5rem
  grid-gutter: 1.5rem
---

## Brand & Style

This design system is engineered for a high-performance, professional utility. The brand personality is precise, authoritative, and focused, catering to students, engineers, and researchers who require immediate, error-free mathematical results. 

The aesthetic style is **Corporate Modern** with a lean towards **Minimalism**. It utilizes a deep, monochromatic foundation to reduce eye strain during long sessions, punctuated by vibrant, functional accents that guide the user's attention to interactive elements and calculated outcomes. The visual narrative emphasizes clarity over decoration, using structured layouts and purposeful whitespace to make complex data feel manageable.

## Colors

The palette is anchored in a professional dark-mode spectrum. 
- **Primary Background (#1E1E2E):** A deep navy-charcoal that provides the base for the entire application workspace.
- **Surface/Card (#2B2B3B):** Used for input containers and grouping related mathematical terms to create subtle depth.
- **Primary Accent (#007ACC):** Reserved for the "Solve" action, active input focus, and primary navigation elements.
- **Functional Colors:** Red (#EF4444) is strictly for invalid equations (e.g., non-real roots or syntax errors), while Green (#10B981) highlights the final calculated values.
- **Typography Colors:** Use pure white (#FFFFFF) for headings and high-emphasis results, and muted slate (#94A3B8) for secondary labels and placeholder text.

## Typography

The design system utilizes **Inter** (as a high-quality alternative to standard system sans-serifs) to ensure maximum legibility for mathematical subscripts and numerical data. 

- **Numerical Hierarchy:** The "Display Result" style is the hero of the interface, ensuring the solution is the first thing the user sees after calculation.
- **Variable Labels:** Use `label-sm` for "a", "b", and "c" coefficient indicators, paired with high-contrast `body-lg` for the actual input text.
- **Mathematical Symbols:** Plus, minus, and square root symbols should match the weight of the adjacent numerical text to maintain visual rhythm.

## Layout & Spacing

The layout follows a **Fixed Centered Grid** for the desktop experience, ensuring the solver remains the focal point regardless of screen width. 

- **Grid System:** A 12-column grid is used, but content is typically constrained to the center 8 columns for focus.
- **Rhythm:** A base-8 scale (8px, 16px, 24px, 32px) governs all margins and padding. 
- **The Input Zone:** Coefficients (a, b, c) are arranged in a horizontal row with 24px gutters between them to simulate the standard algebraic format (ax² + bx + c).
- **Mobile Reflow:** On smaller viewports, the horizontal equation inputs stack vertically to maintain touch-target size and legibility.

## Elevation & Depth

This design system uses **Tonal Layering** combined with **Low-Contrast Outlines** to define hierarchy.

- **Level 0 (Base):** The #1E1E2E background.
- **Level 1 (Cards):** Input areas and history panels use the #2B2B3B surface color with a 1px solid border of #3F3F4E. 
- **Depth Cues:** Avoid heavy drop shadows. Instead, use a subtle 4px blur with 10% opacity for the primary action button to give it a slight "lift" from the surface.
- **Focus State:** When an input is active, the border transitions from the neutral stroke to the Primary Accent (#007ACC), accompanied by a 2px outer glow (inner shadow) of the same color.

## Shapes

The shape language is consistently **Rounded** to soften the technical nature of the application. 

- **Primary Components:** All buttons, input fields, and result cards utilize a `0.5rem` (8px) corner radius.
- **Inner Elements:** Chips or tags within cards (like "Real Roots" or "Complex") use `rounded-lg` (16px) to distinguish them from structural containers.
- **Interactive States:** On hover, clickable cards should subtly scale (102%) while maintaining their corner radius.

## Components

### Buttons
- **Primary Action:** Solid #007ACC background, white `label-md` text, 0.5rem rounding. Used for "Calculate Roots".
- **Secondary/Ghost:** Transparent background with a 1px #3F3F4E border. Used for "Clear All" or "View History".

### Input Fields
- **Coefficient Inputs:** Large, centered text (`body-lg`). The background is #2B2B3B. The label (e.g., "Value of a") sits permanently above the input in `label-sm` slate text.

### Result Cards
- The result is housed in a high-contrast container. The background remains #2B2B3B, but the border color changes based on the outcome: #10B981 for successful real roots, and #EF4444 for errors or non-real results.

### Step-by-Step List
- When the "Show Work" toggle is active, steps are presented in a vertical list. Each step is separated by a thin #3F3F4E horizontal divider with generous 1rem vertical padding.

### Discriminant Chip
- A small, rounded badge at the top of the result card indicating the value of Δ (b² - 4ac), used to categorize the equation type at a glance.